# Proyecto 2: Biblioteca Triple Peaks

La página web de la Biblioteca Triple Peaks es el segundo proyecto en el programa de Desarrollo web en Triple Ten. Fue creado utilizando HTML y CSS, con base en un brief de diseño.

## Características del proyecto

- HTML5 semántico
- Flexbox
